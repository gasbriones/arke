<?php
/**
* @package Component Excel / CSV user Export - UkrSolution for Joomla! 1.6, 1.7, 2x, 3.x* @version 1.4.2
* @author UkrSolution
* @copyright (C) 2015 - UkrSolution
* @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/


defined ('_JEXEC') or die;
?>
<iframe id="frame_faq" src="https://www.ukrsolution.com/FAQ/getEmbeddedForUserExport"></iframe>